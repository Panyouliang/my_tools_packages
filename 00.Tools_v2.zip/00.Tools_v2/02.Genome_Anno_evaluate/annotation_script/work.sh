perl /hwfssz1/ST_EARTH/P18Z10200N0107/P17Z10200N0101_Metazoa_RNA_Editing/liqiye/PC_PA_UN/bin/annotation/personal/UTR/bin/dealUTR.pl ./ ./ utr.gff
