python combine_tissue_gff.py x0combine.lis 0.95 > combine_all_tissue_95.gff
