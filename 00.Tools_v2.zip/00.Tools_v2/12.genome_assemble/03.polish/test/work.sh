python ../polished_v2.py -ref assemble_cyclone.fa -readlis readlis.txt
